/* $Header: /p/tcsh/cvsroot/tcsh/patchlevel.h,v 3.164 2008/09/30 18:57:19 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 16
#define PATCHLEVEL 0
#define DATE "2008-09-30"

#endif /* _h_patchlevel */
